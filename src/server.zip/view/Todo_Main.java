package view;

import controll.Todo_Controller;

public class Todo_Main {

	public static void main(String[] args) {
		Todo_Controller.server();
	}
}